import 'package:flutter_test/flutter_test.dart';
import 'package:upchat/models.dart';

void main() {
  test('ChatMessage : aller-retour JSON', () {
    final m = ChatMessage(
      id: '1',
      convId: 'c',
      senderId: 's',
      senderName: 'Alex',
      text: 'salut',
      ts: 1000,
      mine: true,
      kind: MsgKind.image,
      mediaPath: '/x',
      status: MsgStatus.sent,
    );
    final r = ChatMessage.fromJson(m.toJson());
    expect(r.text, 'salut');
    expect(r.kind, MsgKind.image);
    expect(r.status, MsgStatus.sent);
    expect(r.mine, isTrue);
  });

  test('Story : expire après 24 h', () {
    final now = DateTime.now().millisecondsSinceEpoch;
    final fresh =
        Story(id: 'a', authorId: 'u', authorName: 'A', text: '', ts: now);
    final old = Story(
        id: 'b',
        authorId: 'u',
        authorName: 'A',
        text: '',
        ts: now - 25 * 3600 * 1000);
    expect(fresh.expired, isFalse);
    expect(old.expired, isTrue);
  });

  test('Group : aller-retour JSON', () {
    final g = Group('g', 'Famille', ['a', 'b'], 'a');
    final r = Group.fromJson(g.toJson());
    expect(r.memberIds, ['a', 'b']);
    expect(r.name, 'Famille');
  });
}
