import 'dart:convert';

import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:hive_flutter/hive_flutter.dart';

import 'models.dart';

/// Stockage local chiffré (Hive + AES-256). La clé est conservée dans le
/// Keystore Android via flutter_secure_storage. Les données sont chargées en
/// mémoire au démarrage pour des lectures instantanées.
class Storage {
  Storage._();

  late final Box<String> _msgBox;
  late final Box<String> _peerBox;
  late final Box<String> _groupBox;
  late final Box<String> _storyBox;
  late final Box<String> _prefBox;

  final Map<String, ChatMessage> messages = {};
  final Map<String, Peer> peers = {};
  final Map<String, Group> groups = {};
  final Map<String, Story> stories = {};

  static Future<Box<String>> _open(String name, HiveAesCipher cipher) async {
    try {
      return await Hive.openBox<String>(name, encryptionCipher: cipher);
    } catch (_) {
      // Clé perdue ou boîte corrompue : on repart d'une boîte vide.
      await Hive.deleteBoxFromDisk(name);
      return Hive.openBox<String>(name, encryptionCipher: cipher);
    }
  }

  static Future<Storage> open() async {
    await Hive.initFlutter();
    const secure = FlutterSecureStorage();
    final saved = await secure.read(key: 'hive_key');
    final List<int> key;
    if (saved == null) {
      key = Hive.generateSecureKey();
      await secure.write(key: 'hive_key', value: base64UrlEncode(key));
    } else {
      key = base64Url.decode(saved);
    }
    final cipher = HiveAesCipher(key);
    final s = Storage._();
    s._msgBox = await _open('messages', cipher);
    s._peerBox = await _open('peers', cipher);
    s._groupBox = await _open('groups', cipher);
    s._storyBox = await _open('stories', cipher);
    s._prefBox = await _open('prefs', cipher);

    for (final v in s._msgBox.values) {
      final m = ChatMessage.fromJson(jsonDecode(v) as Map<String, dynamic>);
      s.messages[m.id] = m;
    }
    for (final v in s._peerBox.values) {
      final p = Peer.fromJson(jsonDecode(v) as Map<String, dynamic>);
      s.peers[p.id] = p;
    }
    for (final v in s._groupBox.values) {
      final g = Group.fromJson(jsonDecode(v) as Map<String, dynamic>);
      s.groups[g.id] = g;
    }
    for (final v in s._storyBox.values) {
      final st = Story.fromJson(jsonDecode(v) as Map<String, dynamic>);
      s.stories[st.id] = st;
    }
    s.purgeStories();
    return s;
  }

  String? pref(String k) => _prefBox.get(k);
  Future<void> setPref(String k, String v) => _prefBox.put(k, v);

  void putMessage(ChatMessage m) {
    messages[m.id] = m;
    _msgBox.put(m.id, jsonEncode(m.toJson()));
  }

  void putPeer(Peer p) {
    peers[p.id] = p;
    _peerBox.put(p.id, jsonEncode(p.toJson()));
  }

  void putGroup(Group g) {
    groups[g.id] = g;
    _groupBox.put(g.id, jsonEncode(g.toJson()));
  }

  void putStory(Story s) {
    stories[s.id] = s;
    _storyBox.put(s.id, jsonEncode(s.toJson()));
  }

  /// Supprime les stories de plus de 24 h. Retourne true si quelque chose a changé.
  bool purgeStories() {
    final old = stories.values.where((s) => s.expired).toList();
    for (final s in old) {
      stories.remove(s.id);
      _storyBox.delete(s.id);
    }
    return old.isNotEmpty;
  }
}
