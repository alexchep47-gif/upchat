import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../chat_controller.dart';
import 'chat_screen.dart';

class NearbyScreen extends StatelessWidget {
  const NearbyScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final c = context.watch<ChatController>();
    final connected = c.connectedPeers;
    final pending = c.pendingNearby;
    return ListView(
      children: [
        ListTile(
          leading: Icon(
            c.running ? Icons.wifi_tethering : Icons.wifi_tethering_off,
            color: c.running ? Colors.green : Colors.red,
          ),
          title: Text(c.running ? 'Recherche active' : 'Recherche arrêtée'),
          subtitle: Text(c.error ??
              'Bluetooth + WiFi Direct. Garde UpChat ouvert pour être visible.'),
          trailing: TextButton(
            onPressed: c.restart,
            child: Text(c.running ? 'Relancer' : 'Démarrer'),
          ),
        ),
        const Divider(),
        const Padding(
          padding: EdgeInsets.fromLTRB(16, 8, 16, 4),
          child: Text('Connectés', style: TextStyle(fontWeight: FontWeight.bold)),
        ),
        if (connected.isEmpty)
          const ListTile(
              title: Text('Personne pour le moment — demande à un ami '
                  "d'ouvrir UpChat à proximité.")),
        for (final p in connected)
          ListTile(
            leading: CircleAvatar(
                child: Text(p.name.isEmpty ? '?' : p.name[0].toUpperCase())),
            title: Text(p.name),
            subtitle: const Text('À portée'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => Navigator.push(context,
                MaterialPageRoute(builder: (_) => ChatScreen(convId: p.id))),
          ),
        if (pending.isNotEmpty) ...[
          const Divider(),
          const Padding(
            padding: EdgeInsets.fromLTRB(16, 8, 16, 4),
            child: Text('Détectés (connexion…)',
                style: TextStyle(fontWeight: FontWeight.bold)),
          ),
          for (final n in pending)
            ListTile(
              leading: const SizedBox(
                  width: 24,
                  height: 24,
                  child: CircularProgressIndicator(strokeWidth: 2)),
              title: Text(n),
            ),
        ],
      ],
    );
  }
}
