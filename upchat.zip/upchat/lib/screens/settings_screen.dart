import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../chat_controller.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final c = context.watch<ChatController>();
    return ListView(
      children: [
        ListTile(
          leading: const Icon(Icons.person),
          title: const Text('Mon nom'),
          subtitle: Text(c.myName),
          trailing: const Icon(Icons.edit),
          onTap: () => _rename(context, c),
        ),
        ListTile(
          leading: const Icon(Icons.palette),
          title: const Text('Thème'),
          trailing: DropdownButton<String>(
            value: c.themePref,
            onChanged: (v) => c.setTheme(v ?? 'system'),
            items: const [
              DropdownMenuItem(value: 'system', child: Text('Système')),
              DropdownMenuItem(value: 'light', child: Text('Clair')),
              DropdownMenuItem(value: 'dark', child: Text('Sombre')),
              DropdownMenuItem(value: 'oled', child: Text('OLED (noir)')),
            ],
          ),
        ),
        SwitchListTile(
          secondary: const Icon(Icons.hub),
          title: const Text('Mode mesh (relais 1 saut)'),
          subtitle: const Text(
              'Relaie les messages texte pour des appareils hors de ta portée directe.'),
          value: c.meshOn,
          onChanged: c.setMesh,
        ),
        const Divider(),
        const ListTile(
          leading: Icon(Icons.lock),
          title: Text('Confidentialité'),
          subtitle: Text(
              'Aucun serveur, aucun compte, aucun internet. Messages stockés '
              'sur ton téléphone, chiffrés (AES-256). Les liaisons '
              'Bluetooth/WiFi Direct sont chiffrées par Nearby Connections.'),
        ),
        const ListTile(
          leading: Icon(Icons.info_outline),
          title: Text('Limites'),
          subtitle: Text(
              'Portée : quelques dizaines de mètres. Android uniquement '
              '(Google Play Services requis).'),
        ),
        const ListTile(
          leading: Icon(Icons.copyright),
          title: Text('UpChat'),
          subtitle: Text(
              'Créé par NEMMEGNE CHEPING ALEXANDRE MERVIN — Cameroun'),
        ),
      ],
    );
  }

  Future<void> _rename(BuildContext context, ChatController c) async {
    final ctrl = TextEditingController(text: c.myName);
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Mon nom'),
        content: TextField(controller: ctrl, maxLength: 24),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Annuler')),
          FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('Enregistrer')),
        ],
      ),
    );
    if (ok == true && ctrl.text.trim().isNotEmpty) {
      await c.setName(ctrl.text);
      await c.restart();
    }
    ctrl.dispose();
  }
}
