import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../chat_controller.dart';

class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});

  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  final _ctrl = TextEditingController();

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(28),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Icon(Icons.bluetooth_connected,
                  size: 72, color: Theme.of(context).colorScheme.primary),
              const SizedBox(height: 16),
              Text('UpChat',
                  textAlign: TextAlign.center,
                  style: Theme.of(context).textTheme.headlineLarge),
              const SizedBox(height: 8),
              const Text(
                'Messagerie 100 % hors-ligne.\nAucun internet, aucun serveur : '
                'tes messages passent directement de téléphone à téléphone.',
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 32),
              TextField(
                controller: _ctrl,
                maxLength: 24,
                textCapitalization: TextCapitalization.words,
                decoration: const InputDecoration(
                  labelText: 'Ton prénom ou pseudo',
                  border: OutlineInputBorder(),
                ),
                onSubmitted: (_) => _go(context),
              ),
              const SizedBox(height: 12),
              FilledButton(
                onPressed: () => _go(context),
                child: const Text('Commencer'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _go(BuildContext context) {
    final name = _ctrl.text.trim();
    if (name.isEmpty) return;
    context.read<ChatController>().setName(name);
  }
}
