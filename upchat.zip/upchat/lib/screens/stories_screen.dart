import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';

import '../chat_controller.dart';
import '../models.dart';

class StoriesScreen extends StatelessWidget {
  const StoriesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final c = context.watch<ChatController>();
    final stories = c.stories;
    return Scaffold(
      body: stories.isEmpty
          ? const Center(
              child: Padding(
                padding: EdgeInsets.all(32),
                child: Text(
                  'Aucune story pour le moment.\n'
                  'Les stories durent 24 h et se propagent aux appareils proches.',
                  textAlign: TextAlign.center,
                ),
              ),
            )
          : ListView.builder(
              itemCount: stories.length,
              itemBuilder: (ctx, i) {
                final s = stories[i];
                final mine = s.authorId == c.myId;
                return ListTile(
                  leading: CircleAvatar(
                    backgroundColor: Theme.of(ctx).colorScheme.primary,
                    child: Text(
                      (mine ? c.myName : s.authorName).isEmpty
                          ? '?'
                          : (mine ? c.myName : s.authorName)[0].toUpperCase(),
                      style: TextStyle(
                          color: Theme.of(ctx).colorScheme.onPrimary),
                    ),
                  ),
                  title: Text(mine ? 'Ma story' : s.authorName),
                  subtitle: Text(
                      '${ago(s.ts)}${s.text.isNotEmpty ? ' · ${s.text}' : ''}',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis),
                  onTap: () => _view(ctx, s),
                );
              },
            ),
      floatingActionButton: FloatingActionButton.extended(
        icon: const Icon(Icons.add_a_photo),
        label: const Text('Story'),
        onPressed: () => _compose(context),
      ),
    );
  }

  void _view(BuildContext context, Story s) {
    final path = s.mediaPath;
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => Scaffold(
          backgroundColor: Colors.black,
          appBar: AppBar(title: Text(s.authorName)),
          body: Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                if (path != null && File(path).existsSync())
                  Flexible(child: Image.file(File(path))),
                if (s.text.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.all(20),
                    child: Text(s.text,
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                            color: Colors.white, fontSize: 22)),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _compose(BuildContext context) async {
    final c = context.read<ChatController>();
    final text = TextEditingController();
    String? image;
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setS) => AlertDialog(
          title: const Text('Nouvelle story (24 h)'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: text,
                maxLength: 200,
                decoration: const InputDecoration(labelText: 'Texte'),
              ),
              TextButton.icon(
                icon: const Icon(Icons.photo),
                label: Text(image == null ? 'Ajouter une photo' : 'Photo ajoutée ✓'),
                onPressed: () async {
                  final f = await ImagePicker().pickImage(
                      source: ImageSource.gallery,
                      maxWidth: 1280,
                      imageQuality: 75);
                  if (f != null) setS(() => image = f.path);
                },
              ),
            ],
          ),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(ctx, false),
                child: const Text('Annuler')),
            FilledButton(
                onPressed: () => Navigator.pop(ctx, true),
                child: const Text('Publier')),
          ],
        ),
      ),
    );
    if (ok == true) await c.postStory(text: text.text, imagePath: image);
    text.dispose();
  }
}
