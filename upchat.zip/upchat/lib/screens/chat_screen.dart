import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';

import '../chat_controller.dart';
import '../models.dart';
import 'video_screen.dart';

class ChatScreen extends StatefulWidget {
  final String convId;
  const ChatScreen({super.key, required this.convId});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final _text = TextEditingController();
  late final ChatController _c;

  @override
  void initState() {
    super.initState();
    _c = context.read<ChatController>();
    _c.openConversation(widget.convId);
  }

  @override
  void dispose() {
    _c.closeConversation();
    _text.dispose();
    super.dispose();
  }

  Future<void> _pick(ImageSource src, bool video) async {
    final picker = ImagePicker();
    final XFile? f = video
        ? await picker.pickVideo(
            source: src, maxDuration: const Duration(seconds: 60))
        : await picker.pickImage(
            source: src, maxWidth: 1600, imageQuality: 80);
    if (f == null) return;
    await _c.sendMedia(
        widget.convId, f.path, video ? MsgKind.video : MsgKind.image);
  }

  void _attach() {
    showModalBottomSheet<void>(
      context: context,
      builder: (ctx) => SafeArea(
        child: Wrap(children: [
          ListTile(
            leading: const Icon(Icons.photo),
            title: const Text('Photo (galerie)'),
            onTap: () {
              Navigator.pop(ctx);
              _pick(ImageSource.gallery, false);
            },
          ),
          ListTile(
            leading: const Icon(Icons.photo_camera),
            title: const Text('Prendre une photo'),
            onTap: () {
              Navigator.pop(ctx);
              _pick(ImageSource.camera, false);
            },
          ),
          ListTile(
            leading: const Icon(Icons.videocam),
            title: const Text('Vidéo (galerie, 60 s max)'),
            onTap: () {
              Navigator.pop(ctx);
              _pick(ImageSource.gallery, true);
            },
          ),
        ]),
      ),
    );
  }

  void _send() {
    final t = _text.text;
    if (t.trim().isEmpty) return;
    _text.clear();
    _c.sendText(widget.convId, t);
  }

  @override
  Widget build(BuildContext context) {
    final c = context.watch<ChatController>();
    final msgs = c.messagesOf(widget.convId);
    final isGroup = c.store.groups.containsKey(widget.convId);
    return Scaffold(
      appBar: AppBar(
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(c.titleOf(widget.convId)),
            Text(c.subtitleOf(widget.convId),
                style: Theme.of(context).textTheme.bodySmall),
          ],
        ),
      ),
      body: Column(
        children: [
          Expanded(
            child: msgs.isEmpty
                ? const Center(child: Text('Dis bonjour 👋'))
                : ListView.builder(
                    reverse: true,
                    padding: const EdgeInsets.all(8),
                    itemCount: msgs.length,
                    itemBuilder: (_, i) => _Bubble(
                        m: msgs[msgs.length - 1 - i], showName: isGroup),
                  ),
          ),
          SafeArea(
            top: false,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(4, 4, 4, 6),
              child: Row(children: [
                IconButton(
                    icon: const Icon(Icons.attach_file), onPressed: _attach),
                Expanded(
                  child: TextField(
                    controller: _text,
                    minLines: 1,
                    maxLines: 5,
                    maxLength: 4000,
                    textCapitalization: TextCapitalization.sentences,
                    onChanged: (_) => _c.sendTyping(widget.convId),
                    decoration: InputDecoration(
                      hintText: 'Message',
                      counterText: '',
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(24)),
                      contentPadding: const EdgeInsets.symmetric(
                          horizontal: 16, vertical: 8),
                    ),
                  ),
                ),
                IconButton.filled(
                    icon: const Icon(Icons.send), onPressed: _send),
              ]),
            ),
          ),
        ],
      ),
    );
  }
}

class _Bubble extends StatelessWidget {
  final ChatMessage m;
  final bool showName;
  const _Bubble({required this.m, required this.showName});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final bg = m.mine ? cs.primaryContainer : cs.surfaceContainerHighest;
    return Align(
      alignment: m.mine ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 2),
        padding: const EdgeInsets.fromLTRB(10, 6, 10, 4),
        constraints: BoxConstraints(
            maxWidth: MediaQuery.of(context).size.width * 0.78),
        decoration: BoxDecoration(
            color: bg, borderRadius: BorderRadius.circular(14)),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          mainAxisSize: MainAxisSize.min,
          children: [
            if (showName && !m.mine)
              Align(
                alignment: Alignment.centerLeft,
                child: Text(m.senderName,
                    style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 12,
                        color: cs.primary)),
              ),
            _content(context),
            const SizedBox(height: 2),
            Row(mainAxisSize: MainAxisSize.min, children: [
              Text(hm(m.ts), style: const TextStyle(fontSize: 10)),
              if (m.mine) ...[const SizedBox(width: 4), _tick()],
            ]),
          ],
        ),
      ),
    );
  }

  Widget _tick() {
    switch (m.status) {
      case MsgStatus.pending:
        return const Icon(Icons.access_time, size: 13);
      case MsgStatus.sent:
        return const Icon(Icons.done, size: 14);
      case MsgStatus.delivered:
        return const Icon(Icons.done_all, size: 14);
      case MsgStatus.read:
        return const Icon(Icons.done_all, size: 14, color: Colors.blue);
    }
  }

  Widget _content(BuildContext context) {
    final path = m.mediaPath;
    switch (m.kind) {
      case MsgKind.text:
        return Text(m.text);
      case MsgKind.image:
        if (path == null || !File(path).existsSync()) {
          return const _MediaPlaceholder(icon: Icons.image, label: 'Photo');
        }
        return GestureDetector(
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => Scaffold(
                backgroundColor: Colors.black,
                appBar: AppBar(),
                body: Center(
                    child: InteractiveViewer(child: Image.file(File(path)))),
              ),
            ),
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(10),
            child: Image.file(File(path), width: 220, fit: BoxFit.cover),
          ),
        );
      case MsgKind.video:
        if (path == null || !File(path).existsSync()) {
          return const _MediaPlaceholder(
              icon: Icons.videocam, label: 'Vidéo');
        }
        return GestureDetector(
          onTap: () => Navigator.push(context,
              MaterialPageRoute(builder: (_) => VideoScreen(path: path))),
          child: const _MediaPlaceholder(
              icon: Icons.play_circle_fill, label: 'Lire la vidéo'),
        );
    }
  }
}

class _MediaPlaceholder extends StatelessWidget {
  final IconData icon;
  final String label;
  const _MediaPlaceholder({required this.icon, required this.label});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 200,
      height: 110,
      decoration: BoxDecoration(
          color: Colors.black26, borderRadius: BorderRadius.circular(10)),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [Icon(icon, size: 40), Text(label)],
      ),
    );
  }
}
