import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../chat_controller.dart';
import '../models.dart';
import 'chat_screen.dart';
import 'nearby_screen.dart';
import 'settings_screen.dart';
import 'stories_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _tab = 0;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) context.read<ChatController>().start();
    });
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      const _ConversationsTab(),
      const StoriesScreen(),
      const NearbyScreen(),
      const SettingsScreen(),
    ];
    return Scaffold(
      appBar: AppBar(
        title: const Text('UpChat'),
        actions: [
          Consumer<ChatController>(
            builder: (_, c, __) => Padding(
              padding: const EdgeInsets.only(right: 16),
              child: Icon(
                c.connectedPeers.isNotEmpty
                    ? Icons.bluetooth_connected
                    : Icons.bluetooth_searching,
                color: c.connectedPeers.isNotEmpty
                    ? Colors.green
                    : Theme.of(context).disabledColor,
              ),
            ),
          ),
        ],
      ),
      body: pages[_tab],
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tab,
        onDestinationSelected: (i) => setState(() => _tab = i),
        destinations: const [
          NavigationDestination(
              icon: Icon(Icons.chat_bubble_outline), label: 'Discussions'),
          NavigationDestination(
              icon: Icon(Icons.circle_outlined), label: 'Stories'),
          NavigationDestination(
              icon: Icon(Icons.radar), label: 'À proximité'),
          NavigationDestination(
              icon: Icon(Icons.settings_outlined), label: 'Réglages'),
        ],
      ),
    );
  }
}

class _ConversationsTab extends StatelessWidget {
  const _ConversationsTab();

  @override
  Widget build(BuildContext context) {
    final c = context.watch<ChatController>();
    final convs = c.conversations();
    return Scaffold(
      body: convs.isEmpty
          ? const Center(
              child: Padding(
                padding: EdgeInsets.all(32),
                child: Text(
                  'Aucune discussion.\nOuvre l\'onglet « À proximité » pour '
                  'discuter avec les appareils UpChat autour de toi.',
                  textAlign: TextAlign.center,
                ),
              ),
            )
          : ListView.separated(
              itemCount: convs.length,
              separatorBuilder: (_, __) => const Divider(height: 1),
              itemBuilder: (ctx, i) {
                final v = convs[i];
                final last = v.last;
                String preview = '';
                if (last != null) {
                  preview = switch (last.kind) {
                    MsgKind.image => '📷 Photo',
                    MsgKind.video => '🎬 Vidéo',
                    _ => last.text,
                  };
                }
                return ListTile(
                  leading: Stack(
                    children: [
                      CircleAvatar(
                        child: v.isGroup
                            ? const Icon(Icons.group)
                            : Text(v.title.isEmpty
                                ? '?'
                                : v.title[0].toUpperCase()),
                      ),
                      if (!v.isGroup && c.isOnline(v.id))
                        const Positioned(
                          right: 0,
                          bottom: 0,
                          child: CircleAvatar(
                              radius: 6, backgroundColor: Colors.green),
                        ),
                    ],
                  ),
                  title: Text(v.title),
                  subtitle: Text(
                    c.typingLabel(v.id) ?? preview,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  trailing: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      if (last != null)
                        Text(hm(last.ts),
                            style: Theme.of(context).textTheme.bodySmall),
                      if (v.unread > 0)
                        Container(
                          margin: const EdgeInsets.only(top: 4),
                          padding: const EdgeInsets.symmetric(
                              horizontal: 7, vertical: 2),
                          decoration: BoxDecoration(
                            color: Theme.of(context).colorScheme.primary,
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Text('${v.unread}',
                              style: TextStyle(
                                  color:
                                      Theme.of(context).colorScheme.onPrimary,
                                  fontSize: 12)),
                        ),
                    ],
                  ),
                  onTap: () => Navigator.push(
                    ctx,
                    MaterialPageRoute(
                        builder: (_) => ChatScreen(convId: v.id)),
                  ),
                );
              },
            ),
      floatingActionButton: FloatingActionButton.extended(
        icon: const Icon(Icons.group_add),
        label: const Text('Groupe'),
        onPressed: () => _newGroup(context),
      ),
    );
  }

  Future<void> _newGroup(BuildContext context) async {
    final c = context.read<ChatController>();
    final peers = c.store.peers.values.toList();
    if (peers.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text(
              "Rencontre d'abord quelqu'un à proximité pour créer un groupe.")));
      return;
    }
    final nameCtrl = TextEditingController();
    final selected = <String>{};
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setS) => AlertDialog(
          title: const Text('Nouveau groupe'),
          content: SizedBox(
            width: double.maxFinite,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: nameCtrl,
                  decoration: const InputDecoration(labelText: 'Nom du groupe'),
                ),
                const SizedBox(height: 8),
                Flexible(
                  child: ListView(
                    shrinkWrap: true,
                    children: [
                      for (final p in peers)
                        CheckboxListTile(
                          value: selected.contains(p.id),
                          title: Text(p.name),
                          onChanged: (v) => setS(() {
                            if (v == true) {
                              selected.add(p.id);
                            } else {
                              selected.remove(p.id);
                            }
                          }),
                        ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(ctx, false),
                child: const Text('Annuler')),
            FilledButton(
                onPressed: () => Navigator.pop(ctx, true),
                child: const Text('Créer')),
          ],
        ),
      ),
    );
    if (ok == true && nameCtrl.text.trim().isNotEmpty && selected.isNotEmpty) {
      await c.createGroup(nameCtrl.text, selected.toList());
    }
    nameCtrl.dispose();
  }
}
