class Msg {
  final String id, chat, from, fromName, body, kind; // kind: text|image|video
  final int ts;
  final bool mine;
  int status; // 0 envoyé, 1 reçu, 2 lu
  final String? path;
  Msg({required this.id, required this.chat, required this.from, required this.fromName,
      required this.body, required this.kind, required this.ts, required this.mine,
      this.status = 0, this.path});
  Map<String, dynamic> toMap() => {'id': id, 'chat': chat, 'from': from, 'fn': fromName,
      'body': body, 'kind': kind, 'ts': ts, 'mine': mine, 'st': status, 'path': path};
  factory Msg.fromMap(Map m) => Msg(id: m['id'], chat: m['chat'], from: m['from'],
      fromName: m['fn'] ?? '', body: m['body'] ?? '', kind: m['kind'] ?? 'text',
      ts: m['ts'], mine: m['mine'] == true, status: m['st'] ?? 0, path: m['path']);
}

class Peer {
  final String uid, name;
  Peer(this.uid, this.name);
}
