import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/foundation.dart';
import 'package:nearby_connections/nearby_connections.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:uuid/uuid.dart';

import 'models.dart';
import 'storage.dart';

/// Cœur de l'application : transport Nearby Connections (Bluetooth + WiFi
/// Direct), protocole de paquets JSON, mesh à 1 relais, accusés, stories.
///
/// Protocole : chaque paquet est un JSON {t, id, from, fromName, to, ts, ttl, ...}
/// - `to` = identifiant d'utilisateur destinataire, ou '*' (diffusion).
/// - `ttl` > 0 autorise un relais par un appareil intermédiaire (mesh 1 hop).
/// - Les médias passent par un payload FICHIER, annoncé par un paquet meta
///   contenant l'identifiant du payload (`pid`).
class ChatController extends ChangeNotifier {
  ChatController(this.store) {
    myName = store.pref('name') ?? '';
    themePref = store.pref('theme') ?? 'system';
    meshOn = store.pref('mesh') != '0';
  }

  static const serviceId = 'com.upchat.p2p';

  final Storage store;
  final Nearby _n = Nearby();
  final Uuid _uuid = const Uuid();

  late final String myId = _loadOrCreateId();
  String myName = '';
  String themePref = 'system'; // system | light | dark | oled
  bool meshOn = true;

  bool running = false;
  String? error;
  String? activeConv;

  final Map<String, String> _epToUser = {};
  final Map<String, String> _userToEp = {};
  final Map<String, String> _discovered = {}; // endpointId -> "nom|uid"
  final Set<String> _requesting = {};
  final Set<String> _seen = {};
  final Map<int, Map<String, dynamic>> _pendingMeta = {};
  final Map<int, String> _pendingFiles = {}; // pid -> source en cours de réception
  final Map<int, String> _doneFiles = {}; // pid -> fichier final
  final Map<String, String> _typing = {}; // "conv|uid" -> nom
  final Map<String, Timer> _typingTimers = {};
  final Map<String, int> _lastTypingSent = {};
  Timer? _retryTimer;
  Directory? _mediaDir;

  String _loadOrCreateId() {
    final saved = store.pref('uid');
    if (saved != null) return saved;
    final id = _uuid.v4();
    store.setPref('uid', id);
    return id;
  }

  bool get hasProfile => myName.isNotEmpty;

  // ---------------------------------------------------------------- profil

  Future<void> setName(String name) async {
    myName = name.trim();
    await store.setPref('name', myName);
    notifyListeners();
  }

  Future<void> setTheme(String v) async {
    themePref = v;
    await store.setPref('theme', v);
    notifyListeners();
  }

  Future<void> setMesh(bool v) async {
    meshOn = v;
    await store.setPref('mesh', v ? '1' : '0');
    notifyListeners();
  }

  // ------------------------------------------------------------- transport

  Future<bool> _ensurePermissions() async {
    final res = await [
      Permission.locationWhenInUse,
      Permission.bluetoothScan,
      Permission.bluetoothAdvertise,
      Permission.bluetoothConnect,
      Permission.nearbyWifiDevices,
    ].request();
    // La localisation est demandée sur toutes les versions d'Android ;
    // les autres permissions n'existent que sur les versions récentes.
    return res[Permission.locationWhenInUse]?.isGranted ?? false;
  }

  Future<void> start() async {
    if (running || !hasProfile) return;
    error = null;
    try {
      final docs = await getApplicationDocumentsDirectory();
      _mediaDir = Directory('${docs.path}/media');
      if (!_mediaDir!.existsSync()) _mediaDir!.createSync(recursive: true);

      if (!await _ensurePermissions()) {
        error = 'Permissions refusées : active Bluetooth, WiFi et Localisation '
            "pour UpChat dans les réglages d'Android.";
        notifyListeners();
        return;
      }
      try {
        await _n.stopAdvertising();
        await _n.stopDiscovery();
      } catch (_) {}

      final nick = '$myName|$myId';
      await _n.startAdvertising(
        nick,
        Strategy.P2P_CLUSTER,
        onConnectionInitiated: _onInit,
        onConnectionResult: _onResult,
        onDisconnected: _onDisc,
        serviceId: serviceId,
      );
      await _n.startDiscovery(
        nick,
        Strategy.P2P_CLUSTER,
        onEndpointFound: (id, name, sid) {
          _discovered[id] = name;
          notifyListeners();
          _tryConnect(id);
        },
        onEndpointLost: (id) {
          if (id != null) _discovered.remove(id);
          notifyListeners();
        },
        serviceId: serviceId,
      );
      running = true;
      _retryTimer?.cancel();
      _retryTimer = Timer.periodic(const Duration(seconds: 15), (_) {
        for (final ep in _discovered.keys.toList()) {
          _tryConnect(ep);
        }
        if (store.purgeStories()) notifyListeners();
      });
    } catch (e) {
      error = 'Impossible de démarrer la découverte : $e';
      running = false;
    }
    notifyListeners();
  }

  Future<void> stop() async {
    _retryTimer?.cancel();
    try {
      await _n.stopAdvertising();
      await _n.stopDiscovery();
      await _n.stopAllEndpoints();
    } catch (_) {}
    _epToUser.clear();
    _userToEp.clear();
    _discovered.clear();
    _requesting.clear();
    running = false;
    notifyListeners();
  }

  Future<void> restart() async {
    await stop();
    await start();
  }

  String _displayName(String nick) {
    final i = nick.lastIndexOf('|');
    return i > 0 ? nick.substring(0, i) : nick;
  }

  Future<void> _tryConnect(String ep) async {
    final nick = _discovered[ep];
    if (nick == null) return;
    final i = nick.lastIndexOf('|');
    if (i < 0) return;
    final uid = nick.substring(i + 1);
    if (uid.isEmpty || uid == myId) return;
    if (_epToUser.containsKey(ep) ||
        _requesting.contains(ep) ||
        _userToEp.containsKey(uid)) {
      return;
    }
    // Un seul des deux appareils initie la connexion (id le plus petit),
    // pour éviter les connexions croisées.
    if (myId.compareTo(uid) >= 0) return;
    _requesting.add(ep);
    try {
      await _n.requestConnection(
        '$myName|$myId',
        ep,
        onConnectionInitiated: _onInit,
        onConnectionResult: _onResult,
        onDisconnected: _onDisc,
      );
    } catch (e) {
      _requesting.remove(ep);
    }
  }

  void _onInit(String ep, ConnectionInfo info) {
    _n.acceptConnection(
      ep,
      onPayLoadRecieved: _onPayload,
      onPayloadTransferUpdate: _onTransfer,
    );
  }

  void _onResult(String ep, Status status) {
    _requesting.remove(ep);
    if (status == Status.CONNECTED) {
      _sendTo(ep, {'t': 'hello', 'id': _uuid.v4(), 'uid': myId, 'name': myName});
    }
  }

  void _onDisc(String ep) {
    final u = _epToUser.remove(ep);
    if (u != null && _userToEp[u] == ep) _userToEp.remove(u);
    _requesting.remove(ep);
    notifyListeners();
  }

  void _onPayload(String ep, Payload p) {
    if (p.type == PayloadType.BYTES && p.bytes != null) {
      try {
        final pkt = jsonDecode(utf8.decode(p.bytes!)) as Map<String, dynamic>;
        _route(pkt, ep);
      } catch (e) {
        debugPrint('paquet invalide: $e');
      }
    } else if (p.type == PayloadType.FILE) {
      _pendingFiles[p.id] = p.uri ?? p.filePath ?? '';
    }
  }

  void _onTransfer(String ep, PayloadTransferUpdate u) {
    if (u.status == PayloadStatus.SUCCESS && _pendingFiles.containsKey(u.id)) {
      _finalizeFile(u.id);
    } else if (u.status == PayloadStatus.FAILURE ||
        u.status == PayloadStatus.CANCELED) {
      _pendingFiles.remove(u.id);
      _pendingMeta.remove(u.id);
    }
  }

  Future<void> _finalizeFile(int pid) async {
    final src = _pendingFiles.remove(pid);
    final dir = _mediaDir;
    if (src == null || src.isEmpty || dir == null) return;
    final dest = '${dir.path}/$pid';
    var ok = false;
    try {
      ok = await _n.copyFileAndDeleteOriginal(src, dest);
    } catch (_) {}
    if (!ok) {
      try {
        await File(src).copy(dest);
        ok = true;
      } catch (_) {}
    }
    if (ok) {
      _doneFiles[pid] = dest;
      _tryFinish(pid);
    }
  }

  void _tryFinish(int pid) {
    final meta = _pendingMeta[pid];
    final path = _doneFiles[pid];
    if (meta == null || path == null) return;
    _pendingMeta.remove(pid);
    _doneFiles.remove(pid);
    if (meta['t'] == 'story') {
      _storeStory(meta, path);
    } else {
      _storeIncomingMsg(meta, path);
    }
  }

  // --------------------------------------------------------------- paquets

  Map<String, dynamic> _pkt(String t, String to,
      {int ttl = 1, Map<String, dynamic> extra = const {}}) {
    return {
      't': t,
      'id': _uuid.v4(),
      'from': myId,
      'fromName': myName,
      'to': to,
      'ts': DateTime.now().millisecondsSinceEpoch,
      'ttl': meshOn ? ttl : 0,
      ...extra,
    };
  }

  Future<void> _sendTo(String ep, Map<String, dynamic> pkt) async {
    try {
      await _n.sendBytesPayload(
          ep, Uint8List.fromList(utf8.encode(jsonEncode(pkt))));
    } catch (e) {
      debugPrint('envoi échoué: $e');
    }
  }

  /// Envoie à `pkt['to']` : en direct si connecté, sinon par relais (mesh)
  /// vers tous les voisins. Retourne false si rien n'a pu partir.
  Future<bool> _dispatch(Map<String, dynamic> pkt) async {
    final ep = _userToEp[pkt['to']];
    if (ep != null) {
      await _sendTo(ep, pkt);
      return true;
    }
    if (!meshOn || ((pkt['ttl'] as int?) ?? 0) <= 0 || _epToUser.isEmpty) {
      return false;
    }
    for (final e in _epToUser.keys.toList()) {
      await _sendTo(e, pkt);
    }
    return true;
  }

  Future<void> _route(Map<String, dynamic> p, String fromEp) async {
    if (p['t'] == 'hello') {
      await _onHello(p, fromEp);
      return;
    }
    final id = p['id'] as String?;
    if (id != null) {
      if (!_seen.add(id)) return;
      if (_seen.length > 5000) _seen.clear();
    }
    final to = p['to'] as String?;
    if (to == myId || to == '*') await _handle(p);
    if (meshOn && to != myId && ((p['ttl'] as int?) ?? 0) > 0) {
      _forward(p, fromEp);
    }
  }

  void _forward(Map<String, dynamic> p, String fromEp) {
    if (p['pid'] != null) return; // les médias ne sont pas relayés
    final q = Map<String, dynamic>.from(p)..['ttl'] = (p['ttl'] as int) - 1;
    final direct = _userToEp[p['to']];
    if (direct != null && p['to'] != '*') {
      _sendTo(direct, q);
      return;
    }
    for (final ep in _epToUser.keys.toList()) {
      if (ep != fromEp) _sendTo(ep, q);
    }
  }

  Future<void> _onHello(Map<String, dynamic> p, String ep) async {
    final uid = p['uid'] as String?;
    if (uid == null || uid == myId) return;
    final name = (p['name'] as String?) ?? 'Inconnu';
    final old = _userToEp[uid];
    if (old != null && old != ep) _epToUser.remove(old);
    _epToUser[ep] = uid;
    _userToEp[uid] = ep;
    _rememberPeer(uid, name);
    notifyListeners();
    for (final g in store.groups.values
        .where((g) => g.creatorId == myId && g.memberIds.contains(uid))
        .toList()) {
      await _announceGroup(g, onlyTo: uid);
    }
    await _flushFor(uid);
    for (final s in store.stories.values
        .where((s) => s.authorId == myId && !s.expired)
        .toList()) {
      await _broadcastStory(s, onlyEp: ep);
    }
  }

  Future<void> _handle(Map<String, dynamic> p) async {
    switch (p['t']) {
      case 'msg':
        final pid = p['pid'] as int?;
        if (pid != null) {
          _pendingMeta[pid] = p;
          _tryFinish(pid);
        } else {
          _storeIncomingMsg(p, null);
        }
        break;
      case 'ack':
        _onAck(p);
        break;
      case 'typing':
        _onTyping(p);
        break;
      case 'gcreate':
        _onGroupCreate(p);
        break;
      case 'story':
        final pid = p['pid'] as int?;
        if (pid != null) {
          _pendingMeta[pid] = p;
          _tryFinish(pid);
        } else {
          _storeStory(p, null);
        }
        break;
    }
  }

  void _rememberPeer(String uid, String name) {
    final p = store.peers[uid];
    if (p == null || p.name != name) store.putPeer(Peer(uid, name));
  }

  // -------------------------------------------------------------- messages

  void _storeIncomingMsg(Map<String, dynamic> p, String? mediaPath) {
    final mid = p['mid'] as String;
    final from = p['from'] as String;
    final gid = p['gid'] as String?;
    if (store.messages.containsKey(mid)) {
      _sendAck(from, mid, 'delivered');
      return;
    }
    _rememberPeer(from, (p['fromName'] as String?) ?? 'Inconnu');
    if (gid != null && !store.groups.containsKey(gid)) {
      final members = List<String>.from((p['gm'] as List?) ?? const []);
      if (!members.contains(myId)) return;
      store.putGroup(Group(gid, (p['gn'] as String?) ?? 'Groupe', members, from));
    }
    final conv = gid ?? from;
    final m = ChatMessage(
      id: mid,
      convId: conv,
      senderId: from,
      senderName: (p['fromName'] as String?) ?? '',
      text: (p['text'] as String?) ?? '',
      ts: (p['ots'] as int?) ?? (p['ts'] as int?) ?? DateTime.now().millisecondsSinceEpoch,
      mine: false,
      kind: MsgKind.values[(p['kind'] as int?) ?? 0],
      mediaPath: mediaPath,
      status: MsgStatus.delivered,
    );
    store.putMessage(m);
    _sendAck(from, mid, 'delivered');
    if (activeConv == conv) markRead(conv);
    notifyListeners();
  }

  void _sendAck(String to, String mid, String st) {
    _dispatch(_pkt('ack', to, extra: {'mid': mid, 'st': st}));
  }

  void _onAck(Map<String, dynamic> p) {
    final m = store.messages[p['mid']];
    if (m == null || !m.mine) return;
    final st = p['st'] == 'read' ? MsgStatus.read : MsgStatus.delivered;
    if (st.index > m.status.index) {
      m.status = st;
      store.putMessage(m);
      notifyListeners();
    }
  }

  Future<void> sendText(String convId, String text) async {
    final t = text.trim();
    if (t.isEmpty) return;
    final m = ChatMessage(
      id: _uuid.v4(),
      convId: convId,
      senderId: myId,
      senderName: myName,
      text: t,
      ts: DateTime.now().millisecondsSinceEpoch,
      mine: true,
    );
    store.putMessage(m);
    notifyListeners();
    await _transmit(m);
  }

  Future<void> sendMedia(String convId, String path, MsgKind kind) async {
    final dir = _mediaDir;
    if (dir == null) return;
    final dest = '${dir.path}/${_uuid.v4()}';
    await File(path).copy(dest);
    final m = ChatMessage(
      id: _uuid.v4(),
      convId: convId,
      senderId: myId,
      senderName: myName,
      text: '',
      ts: DateTime.now().millisecondsSinceEpoch,
      mine: true,
      kind: kind,
      mediaPath: dest,
    );
    store.putMessage(m);
    notifyListeners();
    await _transmit(m);
  }

  Future<void> _transmit(ChatMessage m, {String? onlyTo}) async {
    final g = store.groups[m.convId];
    final targets = g != null
        ? g.memberIds.where((u) => u != myId).toList()
        : <String>[m.convId];
    var any = false;
    for (final r in targets) {
      if (onlyTo != null && r != onlyTo) continue;
      final extra = <String, dynamic>{
        'mid': m.id,
        'text': m.text,
        'kind': m.kind.index,
        'ots': m.ts,
        if (g != null) ...{'gid': g.id, 'gn': g.name, 'gm': g.memberIds},
      };
      if (m.kind != MsgKind.text && m.mediaPath != null) {
        if (await _sendFileTo(r, 'msg', extra, m.mediaPath!)) any = true;
      } else {
        if (await _dispatch(_pkt('msg', r, extra: extra))) any = true;
      }
    }
    if (any && m.status == MsgStatus.pending) {
      m.status = MsgStatus.sent;
      store.putMessage(m);
      notifyListeners();
    }
  }

  Future<bool> _sendFileTo(
      String userId, String t, Map<String, dynamic> extra, String path) async {
    final ep = _userToEp[userId];
    if (ep == null) return false;
    try {
      final pid = await _n.sendFilePayload(ep, path);
      await _sendTo(ep, _pkt(t, userId, ttl: 0, extra: {...extra, 'pid': pid}));
      return true;
    } catch (e) {
      debugPrint('envoi fichier échoué: $e');
      return false;
    }
  }

  /// À la (re)connexion d'un pair : renvoie ce qui n'a pas encore été
  /// acquitté (store-and-forward). Le destinataire dédoublonne par id.
  Future<void> _flushFor(String uid) async {
    final limit =
        DateTime.now().millisecondsSinceEpoch - 7 * 24 * 3600 * 1000;
    final todo = store.messages.values
        .where((m) =>
            m.mine &&
            m.ts > limit &&
            m.status.index < MsgStatus.delivered.index)
        .toList()
      ..sort((a, b) => a.ts.compareTo(b.ts));
    for (final m in todo) {
      final g = store.groups[m.convId];
      final concerned = g != null ? g.memberIds.contains(uid) : m.convId == uid;
      if (concerned) await _transmit(m, onlyTo: uid);
    }
  }

  List<ChatMessage> messagesOf(String convId) {
    final list = store.messages.values.where((m) => m.convId == convId).toList()
      ..sort((a, b) => a.ts.compareTo(b.ts));
    return list;
  }

  void openConversation(String id) {
    activeConv = id;
    markRead(id);
  }

  void closeConversation() {
    activeConv = null;
  }

  void markRead(String convId) {
    var changed = false;
    for (final m in store.messages.values
        .where((m) =>
            m.convId == convId && !m.mine && m.status != MsgStatus.read)
        .toList()) {
      m.status = MsgStatus.read;
      store.putMessage(m);
      _sendAck(m.senderId, m.id, 'read');
      changed = true;
    }
    if (changed) notifyListeners();
  }

  // ----------------------------------------------------------------- saisie

  void sendTyping(String convId) {
    final now = DateTime.now().millisecondsSinceEpoch;
    if (now - (_lastTypingSent[convId] ?? 0) < 2500) return;
    _lastTypingSent[convId] = now;
    final g = store.groups[convId];
    final targets = g != null
        ? g.memberIds.where((u) => u != myId).toList()
        : <String>[convId];
    for (final r in targets) {
      if (_userToEp.containsKey(r)) {
        _dispatch(_pkt('typing', r,
            ttl: 0, extra: {if (g != null) 'gid': g.id}));
      }
    }
  }

  void _onTyping(Map<String, dynamic> p) {
    final from = p['from'] as String;
    final conv = (p['gid'] as String?) ?? from;
    final key = '$conv|$from';
    _typing[key] = (p['fromName'] as String?) ?? '';
    _typingTimers[key]?.cancel();
    _typingTimers[key] = Timer(const Duration(seconds: 4), () {
      _typing.remove(key);
      notifyListeners();
    });
    notifyListeners();
  }

  String? typingLabel(String convId) {
    for (final e in _typing.entries) {
      if (e.key.startsWith('$convId|')) {
        return store.groups.containsKey(convId) ? '${e.value} écrit…' : 'écrit…';
      }
    }
    return null;
  }

  // ----------------------------------------------------------------- groupes

  Future<void> createGroup(String name, List<String> memberIds) async {
    final members = {...memberIds, myId}.toList();
    final g = Group(_uuid.v4(), name.trim(), members, myId);
    store.putGroup(g);
    notifyListeners();
    await _announceGroup(g);
  }

  Future<void> _announceGroup(Group g, {String? onlyTo}) async {
    for (final r in g.memberIds.where((u) => u != myId)) {
      if (onlyTo != null && r != onlyTo) continue;
      await _dispatch(_pkt('gcreate', r, extra: {
        'gid': g.id,
        'gn': g.name,
        'gm': g.memberIds,
      }));
    }
  }

  void _onGroupCreate(Map<String, dynamic> p) {
    final gid = p['gid'] as String;
    final members = List<String>.from((p['gm'] as List?) ?? const []);
    if (!members.contains(myId) || store.groups.containsKey(gid)) return;
    store.putGroup(
        Group(gid, (p['gn'] as String?) ?? 'Groupe', members, p['from'] as String));
    notifyListeners();
  }

  // ------------------------------------------------------------------ stories

  Future<void> postStory({String text = '', String? imagePath}) async {
    final dir = _mediaDir;
    String? media;
    if (imagePath != null && dir != null) {
      media = '${dir.path}/${_uuid.v4()}';
      await File(imagePath).copy(media);
    }
    if (text.trim().isEmpty && media == null) return;
    final s = Story(
      id: _uuid.v4(),
      authorId: myId,
      authorName: myName,
      text: text.trim(),
      ts: DateTime.now().millisecondsSinceEpoch,
      mediaPath: media,
    );
    store.putStory(s);
    notifyListeners();
    await _broadcastStory(s);
  }

  Future<void> _broadcastStory(Story s, {String? onlyEp}) async {
    for (final ep in _epToUser.keys.toList()) {
      if (onlyEp != null && ep != onlyEp) continue;
      final extra = <String, dynamic>{
        'sid': s.id,
        'text': s.text,
        'sts': s.ts,
        'author': s.authorId,
        'an': s.authorName,
      };
      if (s.mediaPath != null) {
        try {
          final pid = await _n.sendFilePayload(ep, s.mediaPath!);
          await _sendTo(ep, _pkt('story', '*', ttl: 0, extra: {...extra, 'pid': pid}));
        } catch (e) {
          debugPrint('story média échouée: $e');
        }
      } else {
        await _sendTo(ep, _pkt('story', '*', extra: extra));
      }
    }
  }

  void _storeStory(Map<String, dynamic> p, String? media) {
    final sid = p['sid'] as String;
    final author = p['author'] as String;
    if (author == myId || store.stories.containsKey(sid)) return;
    final s = Story(
      id: sid,
      authorId: author,
      authorName: (p['an'] as String?) ?? '',
      text: (p['text'] as String?) ?? '',
      ts: (p['sts'] as int?) ?? DateTime.now().millisecondsSinceEpoch,
      mediaPath: media,
    );
    if (s.expired) return;
    store.putStory(s);
    notifyListeners();
  }

  List<Story> get stories {
    final list = store.stories.values.where((s) => !s.expired).toList()
      ..sort((a, b) => b.ts.compareTo(a.ts));
    return list;
  }

  // ------------------------------------------------------------ vues d'état

  bool isOnline(String uid) => _userToEp.containsKey(uid);

  List<Peer> get connectedPeers =>
      _userToEp.keys.map((u) => store.peers[u]).whereType<Peer>().toList();

  List<String> get pendingNearby => _discovered.entries
      .where((e) => !_epToUser.containsKey(e.key))
      .map((e) => _displayName(e.value))
      .toList();

  String titleOf(String convId) =>
      store.groups[convId]?.name ?? store.peers[convId]?.name ?? 'Inconnu';

  String subtitleOf(String convId) {
    final t = typingLabel(convId);
    if (t != null) return t;
    final g = store.groups[convId];
    if (g != null) return '${g.memberIds.length} membres';
    return isOnline(convId) ? 'à proximité' : 'hors de portée';
  }

  List<Conv> conversations() {
    final byConv = <String, List<ChatMessage>>{};
    for (final m in store.messages.values) {
      (byConv[m.convId] ??= []).add(m);
    }
    final out = <Conv>[];
    void add(String id, String title, bool isGroup) {
      final list = byConv[id] ?? const <ChatMessage>[];
      ChatMessage? last;
      var unread = 0;
      for (final m in list) {
        if (last == null || m.ts > last.ts) last = m;
        if (!m.mine && m.status != MsgStatus.read) unread++;
      }
      out.add(Conv(id, title, isGroup, last, unread));
    }

    for (final g in store.groups.values) {
      add(g.id, g.name, true);
    }
    for (final p in store.peers.values) {
      if (byConv.containsKey(p.id)) add(p.id, p.name, false);
    }
    out.sort((a, b) => (b.last?.ts ?? 0).compareTo(a.last?.ts ?? 0));
    return out;
  }

  @override
  void dispose() {
    _retryTimer?.cancel();
    for (final t in _typingTimers.values) {
      t.cancel();
    }
    super.dispose();
  }
}
