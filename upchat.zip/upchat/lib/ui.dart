import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'models.dart';
import 'service.dart';

String _hm(int ts) => DateFormat('HH:mm').format(DateTime.fromMillisecondsSinceEpoch(ts));

class UpChatApp extends StatelessWidget {
  const UpChatApp({super.key});
  @override
  Widget build(BuildContext context) {
    final s = context.watch<ChatService>();
    const seed = Color(0xFF128C7E);
    return MaterialApp(
      title: 'UpChat',
      debugShowCheckedModeBanner: false,
      themeMode: [ThemeMode.system, ThemeMode.light, ThemeMode.dark][s.themeIndex],
      theme: ThemeData(colorSchemeSeed: seed, useMaterial3: true),
      darkTheme: ThemeData(
        colorSchemeSeed: seed, brightness: Brightness.dark, useMaterial3: true,
        scaffoldBackgroundColor: Colors.black, // OLED
        appBarTheme: const AppBarTheme(backgroundColor: Colors.black)),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      final s = context.read<ChatService>();
      if (s.myName.isEmpty) await _askName(s);
      await s.start();
    });
  }

  Future<void> _askName(ChatService s) async {
    final c = TextEditingController();
    await showDialog(
      context: context, barrierDismissible: false,
      builder: (_) => AlertDialog(
        title: const Text('Bienvenue sur UpChat'),
        content: TextField(controller: c, decoration: const InputDecoration(labelText: 'Votre nom')),
        actions: [
          TextButton(
            onPressed: () { if (c.text.trim().isNotEmpty) { s.setName(c.text); Navigator.pop(context); } },
            child: const Text('Continuer')),
        ]),
    );
  }

  Future<void> _newGroup(ChatService s) async {
    final c = TextEditingController();
    final peers = s.chatList().where((e) => e.value['g'] != true).toList();
    final chosen = <String>{};
    await showDialog(
      context: context,
      builder: (_) => StatefulBuilder(builder: (ctx, set) => AlertDialog(
        title: const Text('Nouveau groupe'),
        content: SizedBox(width: 300, child: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: c, decoration: const InputDecoration(labelText: 'Nom du groupe')),
          Flexible(child: ListView(shrinkWrap: true, children: [
            for (final p in peers)
              CheckboxListTile(
                value: chosen.contains(p.key), title: Text(p.value['name']),
                onChanged: (v) => set(() => v == true ? chosen.add(p.key) : chosen.remove(p.key))),
          ])),
        ])),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Annuler')),
          TextButton(
            onPressed: () {
              if (c.text.trim().isNotEmpty && chosen.isNotEmpty) {
                s.createGroup(c.text.trim(), chosen.toList());
                Navigator.pop(ctx);
              }
            },
            child: const Text('Créer')),
        ])),
    );
  }

  @override
  Widget build(BuildContext context) {
    final s = context.watch<ChatService>();
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('UpChat'),
          actions: [
            IconButton(icon: const Icon(Icons.brightness_6), onPressed: s.cycleTheme),
            IconButton(icon: const Icon(Icons.group_add), onPressed: () => _newGroup(s)),
          ],
          bottom: const TabBar(tabs: [Tab(text: 'Discussions'), Tab(text: 'À proximité'), Tab(text: 'Stories')]),
        ),
        body: TabBarView(children: [_chats(s), _nearby(s), _stories(s)]),
      ),
    );
  }

  Widget _chats(ChatService s) {
    final l = s.chatList();
    if (l.isEmpty) return const Center(child: Text('Aucune discussion.\nRapprochez deux téléphones UpChat.', textAlign: TextAlign.center));
    return ListView(children: [
      for (final e in l)
        ListTile(
          leading: CircleAvatar(child: Icon(e.value['g'] == true ? Icons.group : Icons.person)),
          title: Text(e.value['name']),
          subtitle: Text(_preview(s.lastMsg(e.key)), maxLines: 1, overflow: TextOverflow.ellipsis),
          trailing: s.lastMsg(e.key) == null ? null : Text(_hm(s.lastMsg(e.key)!.ts)),
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ChatPage(chatId: e.key))),
        ),
    ]);
  }

  String _preview(Msg? m) => m == null ? 'Nouvelle discussion' : (m.kind == 'image' ? '📷 Photo' : m.kind == 'video' ? '🎬 Vidéo' : m.body);

  Widget _nearby(ChatService s) => ListView(children: [
    ListTile(
      leading: Icon(s.running ? Icons.radar : Icons.error_outline),
      title: Text(s.running ? 'Recherche d\'appareils proches…' : (s.error ?? 'Radio arrêtée')),
      trailing: IconButton(icon: const Icon(Icons.refresh), onPressed: s.start)),
    for (final p in s.connected.values)
      ListTile(leading: const Icon(Icons.bluetooth_connected), title: Text(p.name), subtitle: const Text('Connecté')),
    for (final n in s.found.entries.where((e) => !s.connected.containsKey(e.key)))
      ListTile(leading: const Icon(Icons.bluetooth_searching), title: Text(n.value.split('|').first), subtitle: const Text('Connexion…')),
  ]);

  Widget _stories(ChatService s) {
    final l = s.stories();
    return ListView(children: [
      ListTile(
        leading: const CircleAvatar(child: Icon(Icons.add)),
        title: const Text('Ajouter une story (24 h)'),
        onTap: () async {
          final c = TextEditingController();
          await showDialog(context: context, builder: (ctx) => AlertDialog(
            content: TextField(controller: c, maxLength: 200, decoration: const InputDecoration(labelText: 'Votre story')),
            actions: [TextButton(onPressed: () { if (c.text.trim().isNotEmpty) s.postStory(c.text.trim()); Navigator.pop(ctx); }, child: const Text('Publier'))]));
        }),
      for (final st in l)
        ListTile(
          leading: CircleAvatar(child: Text((st['fn'] as String).isEmpty ? '?' : (st['fn'] as String)[0].toUpperCase())),
          title: Text(st['fn'] ?? ''), subtitle: Text(st['body'] ?? ''), trailing: Text(_hm(st['ts']))),
    ]);
  }
}

class ChatPage extends StatefulWidget {
  final String chatId;
  const ChatPage({super.key, required this.chatId});
  @override
  State<ChatPage> createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> {
  final _c = TextEditingController();
  @override
  void initState() { super.initState(); context.read<ChatService>().markRead(widget.chatId); }

  Future<void> _pick(ChatService s, bool video) async {
    final p = ImagePicker();
    final f = video ? await p.pickVideo(source: ImageSource.gallery) : await p.pickImage(source: ImageSource.gallery, imageQuality: 80);
    if (f != null) await s.sendMedia(widget.chatId, f.path, video ? 'video' : 'image');
  }

  @override
  Widget build(BuildContext context) {
    final s = context.watch<ChatService>();
    final msgs = s.messages(widget.chatId).reversed.toList();
    s.markRead(widget.chatId);
    return Scaffold(
      appBar: AppBar(title: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(s.chatName(widget.chatId)),
        if (s.isTyping(widget.chatId)) const Text('est en train d\'écrire…', style: TextStyle(fontSize: 12)),
      ])),
      body: Column(children: [
        Expanded(child: ListView.builder(
          reverse: true, padding: const EdgeInsets.all(8), itemCount: msgs.length,
          itemBuilder: (_, i) => _Bubble(m: msgs[i]))),
        SafeArea(child: Row(children: [
          IconButton(icon: const Icon(Icons.image), onPressed: () => _pick(s, false)),
          IconButton(icon: const Icon(Icons.videocam), onPressed: () => _pick(s, true)),
          Expanded(child: TextField(
            controller: _c, onChanged: (_) => s.sendTyping(widget.chatId),
            decoration: const InputDecoration(hintText: 'Message', border: InputBorder.none))),
          IconButton(icon: const Icon(Icons.send), onPressed: () {
            final t = _c.text.trim();
            if (t.isNotEmpty) { s.sendText(widget.chatId, t); _c.clear(); }
          }),
        ])),
      ]),
    );
  }
}

class _Bubble extends StatelessWidget {
  final Msg m;
  const _Bubble({required this.m});
  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final tick = !m.mine ? '' : (m.status == 0 ? ' ✓' : ' ✓✓');
    return Align(
      alignment: m.mine ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 2),
        padding: const EdgeInsets.all(8),
        constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.78),
        decoration: BoxDecoration(
          color: m.mine ? cs.primaryContainer : cs.surfaceContainerHighest,
          borderRadius: BorderRadius.circular(12)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          if (!m.mine && m.fromName.isNotEmpty) Text(m.fromName, style: TextStyle(fontSize: 11, color: cs.primary)),
          if (m.kind == 'image' && m.path != null && File(m.path!).existsSync())
            ClipRRect(borderRadius: BorderRadius.circular(8), child: Image.file(File(m.path!), width: 220))
          else if (m.kind == 'video')
            const Row(mainAxisSize: MainAxisSize.min, children: [Icon(Icons.play_circle), SizedBox(width: 6), Text('Vidéo')])
          else if (m.kind == 'image')
            const Text('📷 Photo en cours de réception…'),
          if (m.body.isNotEmpty) Text(m.body),
          Align(alignment: Alignment.bottomRight, child: Text('${_hm(m.ts)}$tick',
              style: TextStyle(fontSize: 10, color: m.status == 2 && m.mine ? Colors.lightBlue : null))),
        ]),
      ),
    );
  }
}
