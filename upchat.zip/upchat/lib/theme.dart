import 'package:flutter/material.dart';

ThemeData lightTheme() => ThemeData(
      useMaterial3: true,
      colorSchemeSeed: const Color(0xFF128C7E),
      brightness: Brightness.light,
    );

ThemeData darkTheme() => ThemeData(
      useMaterial3: true,
      colorSchemeSeed: const Color(0xFF25D366),
      brightness: Brightness.dark,
    );

/// Thème sombre « OLED » : fond noir pur pour économiser la batterie.
ThemeData oledTheme() {
  final base = darkTheme();
  return base.copyWith(
    scaffoldBackgroundColor: Colors.black,
    canvasColor: Colors.black,
    appBarTheme: const AppBarTheme(
      backgroundColor: Colors.black,
      surfaceTintColor: Colors.transparent,
    ),
    navigationBarTheme: const NavigationBarThemeData(
      backgroundColor: Colors.black,
      surfaceTintColor: Colors.transparent,
    ),
  );
}
