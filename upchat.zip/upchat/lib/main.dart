import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:provider/provider.dart';
import 'service.dart';
import 'ui.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Hive.initFlutter();
  const ss = FlutterSecureStorage();
  var k = await ss.read(key: 'hive_key');
  if (k == null) {
    k = base64UrlEncode(Hive.generateSecureKey());
    await ss.write(key: 'hive_key', value: k);
  }
  final cipher = HiveAesCipher(base64Url.decode(k)); // chiffrement AES-256 local
  final msgs = await Hive.openBox('msgs', encryptionCipher: cipher);
  final chats = await Hive.openBox('chats', encryptionCipher: cipher);
  final stories = await Hive.openBox('stories', encryptionCipher: cipher);
  final prefs = await Hive.openBox('prefs', encryptionCipher: cipher);
  final svc = ChatService(msgs, chats, stories, prefs)..init();
  runApp(ChangeNotifierProvider.value(value: svc, child: const UpChatApp()));
}
