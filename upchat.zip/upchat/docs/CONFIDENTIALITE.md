# Confidentialité (modèle, à faire valider par un juriste avant diffusion publique)

- **Aucun serveur, aucun compte, aucun internet** : UpChat n'envoie rien en ligne.
- **Stockage local** : messages, médias, contacts rencontrés et stories restent sur le téléphone, chiffrés (AES-256); la clé est dans le Keystore Android.
- **Données échangées entre appareils proches** : nom d'affichage, identifiant aléatoire, messages et médias. Les liaisons sont chiffrées par Nearby Connections.
- **Mesh** : si activé, des appareils intermédiaires relaient temporairement des messages texte qui ne leur sont pas destinés.
- **Permissions** : Bluetooth, WiFi, appareils Wi-Fi à proximité, localisation (exigée par Android pour la détection d'appareils; la position n'est ni lue ni stockée par UpChat).
- **Suppression** : désinstaller l'application efface toutes les données.

Ce document est un modèle d'information, pas un avis juridique.
