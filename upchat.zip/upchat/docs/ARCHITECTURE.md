# Architecture UpChat

## Vue d'ensemble

```
UI (screens/) ──► ChatController ──► Nearby Connections (BT + WiFi Direct)
                       │
                       └──► Storage (Hive AES-256, cache mémoire)
```

- `ChatController` : transport, protocole, mesh, accusés, groupes, stories.
- `Storage` : persistance chiffrée, chargée en mémoire au démarrage.

## Protocole

Paquet JSON (payload BYTES, < 32 Ko) :
`{t, id, from, fromName, to, ts, ttl, ...}`

| t | rôle |
|---|------|
| hello | échange d'identité à la connexion (uid, nom) |
| msg | message (texte, ou meta d'un média avec `pid`) |
| ack | accusé `delivered` / `read` |
| typing | indicateur de saisie |
| gcreate | annonce d'un groupe |
| story | story (texte, ou meta avec `pid`) |

Médias : payload FILE envoyé d'abord, puis paquet meta portant le `pid`. Le
récepteur associe fichier et meta dans n'importe quel ordre d'arrivée.

Groupes : un message de groupe est envoyé en une copie par membre (routage
uniquement par id d'utilisateur), avec nom et membres joints pour auto-créer
le groupe chez un membre qui l'ignore.

## ADR-1 : stratégie P2P_CLUSTER, un seul initiateur

**Contexte** : plusieurs appareils, connexions croisées possibles.
**Décision** : `Strategy.P2P_CLUSTER`; l'appareil dont l'id est le plus petit initie la connexion.
**Conséquences** : pas de doublons; chaque appareil annonce et découvre en permanence (consommation batterie plus élevée).

## ADR-2 : mesh à 1 saut par TTL

**Décision** : `ttl = 1` sur les paquets texte; un voisin qui reçoit un paquet non destiné à lui le relaie avec `ttl - 1` (déduplication par `id`).
**Conséquences** : couvre A–B–C sans routage complexe; pas de livraison garantie ni de relais média.

## ADR-3 : store-and-forward

**Décision** : à chaque `hello`, renvoi des messages non acquittés (7 jours max); le récepteur dédoublonne par id de message.
**Conséquences** : livraison à la reconnexion sans serveur; renvois possibles (idempotents).

## À revisiter

- Chiffrement de bout en bout applicatif (clés par pair) en plus du chiffrement de liaison Nearby.
- Service au premier plan Android pour rester visible écran éteint.
- Relais des médias, plus d'un saut.
