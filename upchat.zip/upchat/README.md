# UpChat

**Messagerie P2P 100 % offline** — Bluetooth + WiFi Direct (Nearby Connections). Android uniquement.

Créé par **NEMMEGNE CHEPING ALEXANDRE MERVIN** (Cameroun). Projet personnel.

## Fonctionnalités
1-à-1 · groupes · images/vidéos (transfert binaire direct) · stories 24 h · mesh (relais 1 hop pour texte, accusés, stories, groupes) · accusés de réception/lecture · « en train d'écrire » · stockage chiffré AES-256 (Hive, clé dans le Keystore) · thème clair/sombre OLED · interface en français.

## Limites
Portée de quelques dizaines de mètres. Android ↔ Android (Google Play Services requis). Les médias ne sont pas relayés par le mesh. Le transport Nearby est chiffré par Google ; il n'y a pas de chiffrement de bout en bout applicatif.

## Compilation
Push sur `main` → onglet **Actions** → **Build APK** → artefact `upchat-apk`. Le workflow génère le squelette Android et applique `tool/patch_android.py` (permissions, minSdk 23).
Localement : `flutter create --platforms=android . && python3 tool/patch_android.py && flutter run`.
