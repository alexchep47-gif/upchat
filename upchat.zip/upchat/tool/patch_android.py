"""Applique la config Android requise par Nearby Connections après `flutter create`."""
import glob, re
PERMS = """    <uses-permission android:name="android.permission.ACCESS_WIFI_STATE"/>
    <uses-permission android:name="android.permission.CHANGE_WIFI_STATE"/>
    <uses-permission android:name="android.permission.BLUETOOTH" android:maxSdkVersion="30"/>
    <uses-permission android:name="android.permission.BLUETOOTH_ADMIN" android:maxSdkVersion="30"/>
    <uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" android:maxSdkVersion="32"/>
    <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" android:maxSdkVersion="32"/>
    <uses-permission android:name="android.permission.BLUETOOTH_ADVERTISE"/>
    <uses-permission android:name="android.permission.BLUETOOTH_CONNECT"/>
    <uses-permission android:name="android.permission.BLUETOOTH_SCAN" android:usesPermissionFlags="neverForLocation"/>
    <uses-permission android:name="android.permission.NEARBY_WIFI_DEVICES" android:usesPermissionFlags="neverForLocation"/>
    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" android:maxSdkVersion="32"/>
"""
p = "android/app/src/main/AndroidManifest.xml"
s = open(p).read()
if "NEARBY_WIFI_DEVICES" not in s:
    s = s.replace("<application", PERMS + "    <application", 1)
s = re.sub(r'android:label="[^"]*"', 'android:label="UpChat"', s, count=1)
open(p, "w").write(s)
for g in glob.glob("android/app/build.gradle*"):
    t = open(g).read()
    kts = g.endswith(".kts")
    t = re.sub(r'minSdk(Version)?\s*=?\s*flutter\.minSdkVersion', 'minSdk = 23' if kts else 'minSdkVersion 23', t)
    open(g, "w").write(t)
print("Android patché")
