#!/usr/bin/env bash
# Génère le dossier android/ (Flutter le recrée à l'identique de la version
# installée), puis applique la config UpChat : manifeste Nearby + minSdk 23.
set -euo pipefail
cd "$(dirname "$0")/.."

if [ ! -d android ]; then
  flutter create . --platforms=android --org com.upchat --project-name upchat
  # flutter create ne doit jamais écraser notre code
  git checkout -- lib test pubspec.yaml analysis_options.yaml 2>/dev/null || true
fi

cp android_overrides/AndroidManifest.xml android/app/src/main/AndroidManifest.xml

GRADLE=$(ls android/app/build.gradle.kts android/app/build.gradle 2>/dev/null | head -n1)
sed -i -E 's/minSdk(Version)?( *=)? *flutter\.minSdkVersion/minSdk = 23/' "$GRADLE"
grep -Eq 'minSdk(Version)? *=? *23' "$GRADLE" || {
  echo "ERREUR: minSdk 23 non appliqué dans $GRADLE" >&2
  exit 1
}
echo "android/ prêt (minSdk 23, manifeste Nearby)."
